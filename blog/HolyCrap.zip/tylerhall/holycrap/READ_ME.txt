================================
Holy Crap!
--------------------------------
Holy Crap! is a pane-less Mint pepper that sends an email alert when your website receives a referal from the front page (or popular section) of traffic generating sites like del.icio.us, Digg, or Slashdot.

Since traffic from those sites tend to come in huge burts, the Pepper is smart enough to not send you a thousand emails. Instead, it sends you a single alert when it first detects a referral from a popular site. All future alerts for that particular site are turned off until you view your Mint preferences - at which point everything is "reset" and you'll start receiving alerts again.

================================
Installation:
--------------------------------
1.  Download HolyCrap.zip
2.  Extract the contents
3.  Upload the /tylerhall/ folder and it's contents to the /mint/pepper/ directory on your server
4.  Navigate to your Mint preferences
5.  Click "Install" in the pepper list pane
6.  Click the "Install" button for the Holy Crap! pepper
7.  Click "Okay"
8.  Navigate to the Holy Crap! pepper preferences
9.  Enter the email address you would like to notify. You may also add a string that will be prepended to the subject line of any emails that get sent (for mail filtering purposes).
10. All done!

================================
Version History
--------------------------------
1.0.1 - Removed debugging code left in by mistake (I'm an idiot).
1.0 - Initial Release

================================
Support and Requests:
--------------------------------
If you would like to contact me regarding issues or requests, please email me at tylerhall@gmail.com

Holy Crap! is developed by Tyler Hall and is released under Creative Commons Attribution 2.5 license. [http://creativecommons.org/licenses/by/2.5/]