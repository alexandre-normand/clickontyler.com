<?PHP
	/******************************************************************************
	 Pepper

	 Developer		: Tyler Hall
	 Developer Site	: http://clickontyler.com
	 Pepper Name	: Holy Crap!

	 ******************************************************************************/

	if (!defined('MINT')) { header('Location:/'); }; // Prevent viewing this file 


	$installPepper = "TH_HolyCrap";


	class TH_HolyCrap extends Pepper
	{
		var $version    = 101;
		var $info       = array
		(
			'pepperName'    => 'Holy Crap!',
			'pepperUrl'     => 'http://clickontyler.com/blog/2008/04/holy-crap-mint-plugin/',
			'pepperDesc'    => 'Sends an email alert when your website becomes popular on a traffic generating site.',
			'developerName' => 'Tyler Hall',
			'developerUrl'  => 'http://clickontyler.com/'
		);
		var $prefs = array
		(
			'th_sites' => array(
								array('name'    => 'del.icio.us',
								      'trigger' => '!^http://del\.icio\.us/popular.*!'),

								array('name'    => 'Digg',
								      'trigger' => '!^http://digg\.com(/(all|news))/?$!'),

								array('name'    => 'Daring Fireball',
								      'trigger' => '!^http://daringfireball\.net.*!'),

								array('name'    => 'Reddit',
								      'trigger' => '!^http://reddit\.com(/r/[a-zA-Z]+)?/?$!'),

								array('name'    => 'Slashdot',
								      'trigger' =>'!^http://slashdot\.org/?$!'),
							),

			'th_email'     => '',
			'th_subject'   => '[Holy Crap!]'
		);
		
		function isCompatible()
		{
			if($this->Mint->version < 120)
				return array("isCompatible"	=> false, "explanation"	=> "<p>This Pepper is only compatible with Mint 1.2 and higher.</p>");
			else
				return array('isCompatible'	=> true);
		}
	
		function onDisplayPreferences()
		{
			$th_sites   = $this->prefs['th_sites']; 
			$th_email   = $this->prefs['th_email'];
			$th_subject = $this->prefs['th_subject'];

			$preferences['Alert Settings'] = "
			<table>
				<tr>
					<td scope=\"row\">Email alert to:</td>
					<td>
						<span>
							<input type=\"text\" name=\"th_email\" value=\"$th_email\"/>
						</span>
					</td>
				</tr>
				<tr>
					<td scope=\"row\">Prepend subject with:</td>
					<td>
						<span>
							<input type=\"text\" name=\"th_subject\" value=\"$th_subject\"/>
						</span>
					</td>
				</tr>
			</table>";

			$preferences['Sites to Monitor'] = "<table>";
			foreach($th_sites as $k => $v)
			{
				$checked = isset($v['status']) ? $this->setChecked($v['status']) : '';
				$preferences['Sites to Monitor'] .= "<tr>";
				$preferences['Sites to Monitor'] .= "<td scope=\"row\"><label for=\"th_$k\" $style><input type=\"checkbox\" id=\"th_$k\" value=\"1\" name=\"th_$k\" $checked/> {$v['name']}</label></td>";
				$preferences['Sites to Monitor'] .= "</tr>";
			}
			$preferences['Sites to Monitor'] .= "</table>";
			
			return $preferences;
		}

		function onSavePreferences()
		{
			$this->prefs['th_email'] = $_POST['th_email'];
			$this->prefs['th_subject'] = $_POST['th_subject'];

			foreach($this->prefs['th_sites'] as $k => $v)
				$this->prefs['th_sites'][$k]['status'] = isset($_POST["th_$k"]) ? 1 : 0;
		}

	    function onRecord()
		{
	 		$referer = $_GET['referer'];
			foreach($this->prefs['th_sites'] as $k => $v)
			{
				if($this->prefs['th_sites'][$k]['status'] == 1 && preg_match($v['trigger'], $referer) > 0)
				{
					$this->email($v);
					$this->prefs['th_sites'][$k]['status'] = 2;
				}
			}
		}

		function onDisplaySupplemental($pane) 
		{
			return '<style>.th_hot { font-color:red; font-weight:bold; }</style>';
		}
		
		function email($site)
		{
			if(!empty($this->prefs['th_email']))
				mail($this->prefs['th_email'], $this->prefs['th_subject'] . ' ' . $site['name'], "Your website is now popular on {$site['name']}!");
		}
		
		function setChecked($val)
		{
			if($val == 0) return '';
			if($val == 1 || $val == 2) return 'checked="checked"';
		}
	}